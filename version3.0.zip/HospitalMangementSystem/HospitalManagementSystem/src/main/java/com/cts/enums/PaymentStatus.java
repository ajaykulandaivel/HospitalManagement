package com.cts.enums;

public enum PaymentStatus {
	PAID,UNPAID
}
