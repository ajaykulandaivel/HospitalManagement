package com.cts.enums;

public enum Status {
    CONFIRMED,
    CANCELLED,
    MEDICAL_HISTORY_UPDATE,
    COMPLETED
}