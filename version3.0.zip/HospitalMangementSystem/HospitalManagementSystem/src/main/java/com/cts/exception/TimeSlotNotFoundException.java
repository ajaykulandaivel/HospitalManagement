package com.cts.exception;

public class TimeSlotNotFoundException extends RuntimeException {

	public TimeSlotNotFoundException(String message) {
		super(message);
	}
}
