package com.cts.enums;

public enum UserRole {
	ADMIN,PATIENT,DOCTOR
}
